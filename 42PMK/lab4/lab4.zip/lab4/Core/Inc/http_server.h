/*
 * http_server.h
 *
 *  Created on: Mar 27, 2025
 *      Author: dmytro
 */

#ifndef INC_HTTP_SERVER_H_
#define INC_HTTP_SERVER_H_

#include "lwip/tcp.h"
#include "main.h"

void http_server_init(void);

#endif /* INC_HTTP_SERVER_H_ */
