/*
 * tcp_client.h
 *
 *  Created on: Mar 27, 2025
 *      Author: dmytro
 */

#ifndef INC_TCP_CLIENT_H_
#define INC_TCP_CLIENT_H_

#include "lwip/tcp.h"
#include "main.h"

void tcp_client_init(void);
void tcp_client_send(const char *message);

#endif /* INC_TCP_CLIENT_H_ */
