/*
 * tcp_server.h
 *
 *  Created on: Mar 27, 2025
 *      Author: dmytro
 */

#ifndef INC_TCP_SERVER_H_
#define INC_TCP_SERVER_H_

#include "lwip/tcp.h"
#include "main.h"

#define TCP_PORT 8080
#define MAX_CLIENTS 4

void tcp_server_init(void);
err_t tcp_server_accept(void *arg, struct tcp_pcb *newpcb, err_t err);
err_t tcp_server_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err);

#endif /* INC_TCP_SERVER_H_ */
