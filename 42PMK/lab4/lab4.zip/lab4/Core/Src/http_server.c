/*
 * http_server.c
 *
 *  Created on: Mar 27, 2025
 *      Author: dmytro
 */

#include "http_server.h"

#define HTTP_PORT 80

static const char http_header[] = "HTTP/1.1 200 OK\r\nContent-type: text/html\r\n\r\n";
static const char http_body[] = "Hello world";

static err_t http_server_recv(void *arg, struct tcp_pcb *pcb, struct pbuf *p, err_t err) {
    if (p != NULL) {
        tcp_recved(pcb, p->tot_len);
        tcp_write(pcb, http_header, sizeof(http_header)-1, TCP_WRITE_FLAG_COPY);
        tcp_write(pcb, http_body, sizeof(http_body)-1, TCP_WRITE_FLAG_COPY);
        pbuf_free(p);
    }
    return ERR_OK;
}

static err_t http_server_accept(void *arg, struct tcp_pcb *pcb, err_t err) {
    tcp_recv(pcb, http_server_recv);
    return ERR_OK;
}

void http_server_init(void) {
    struct tcp_pcb *pcb = tcp_new();
    tcp_bind(pcb, IP_ADDR_ANY, HTTP_PORT);
    pcb = tcp_listen(pcb);
    tcp_accept(pcb, http_server_accept);
}
