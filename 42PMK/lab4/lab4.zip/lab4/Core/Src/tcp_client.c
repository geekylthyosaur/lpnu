/*
 * tcp_client.c
 *
 *  Created on: Mar 27, 2025
 *      Author: dmytro
 */

#include "tcp_client.h"
#include "string.h"

static struct tcp_pcb *tcp_client_pcb;
static ip_addr_t server_ip = IPADDR4_INIT_BYTES(1, 1, 1, 1);
#define SERVER_PORT 80

void tcp_client_init(void) {
	tcp_client_pcb = tcp_new();
	if (tcp_client_pcb != NULL) {
		tcp_connect(tcp_client_pcb, &server_ip, SERVER_PORT, NULL);
	}
}

void tcp_client_send(const char *message) {
	if (tcp_client_pcb != NULL) {
		struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, strlen(message), PBUF_RAM);
		if (p != NULL) {
			memcpy(p->payload, message, strlen(message));
			tcp_write(tcp_client_pcb, p->payload, p->len, TCP_WRITE_FLAG_COPY);
			pbuf_free(p);
		}
	}
}
