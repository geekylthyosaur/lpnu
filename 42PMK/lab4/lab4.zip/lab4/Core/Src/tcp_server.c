/*
 * tcp_server.c
 *
 *  Created on: Mar 27, 2025
 *      Author: dmytro
 */

#include "tcp_server.h"

static struct tcp_pcb *tcp_server_pcb;
static struct tcp_pcb *client_pcbs[MAX_CLIENTS];

void tcp_server_init(void) {
    tcp_server_pcb = tcp_new();
    if (tcp_server_pcb != NULL) {
        err_t err = tcp_bind(tcp_server_pcb, IP_ADDR_ANY, TCP_PORT);
        if (err == ERR_OK) {
            tcp_server_pcb = tcp_listen(tcp_server_pcb);
            tcp_accept(tcp_server_pcb, tcp_server_accept);
        }
    }
}

err_t tcp_server_accept(void *arg, struct tcp_pcb *newpcb, err_t err) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (client_pcbs[i] == NULL) {
            client_pcbs[i] = newpcb;
            tcp_arg(newpcb, (void*)(intptr_t)i);
            tcp_recv(newpcb, tcp_server_recv);
            return ERR_OK;
        }
    }
    tcp_close(newpcb);
    return ERR_CONN;
}

err_t tcp_server_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err) {
    if (p != NULL) {
    	// TODO
        tcp_recved(tpcb, p->tot_len);
        pbuf_free(p);
    } else if (err == ERR_OK) {
        int client_id = (int)(intptr_t)arg;
        client_pcbs[client_id] = NULL;
        tcp_close(tpcb);
    }
    return ERR_OK;
}
